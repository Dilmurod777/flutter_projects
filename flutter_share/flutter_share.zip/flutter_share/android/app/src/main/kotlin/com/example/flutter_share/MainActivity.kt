package com.example.flutter_share

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
