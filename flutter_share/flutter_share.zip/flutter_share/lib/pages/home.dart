import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_share/models/user.dart';
import 'package:flutter_share/pages/activity_feed.dart';
import 'package:flutter_share/pages/create_account.dart';
import 'package:flutter_share/pages/profile.dart';
import 'package:flutter_share/pages/search.dart';
import 'package:flutter_share/pages/timeline.dart';
import 'package:flutter_share/pages/upload.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_share/data/instances.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool _isAuth = false;

  GoogleSignIn _googleSignIn = GoogleSignIn();
  DateTime _timestamp = DateTime.now();

  int _currentPage = 0;
  PageController _pageController;

  User _currentUser;

  @override
  void initState() {
    super.initState();

    usersRef = FirebaseFirestore.instance.collection('users');
    postsRef = FirebaseFirestore.instance.collection('posts');
    storageRef = FirebaseStorage.instance.ref();

    _pageController = PageController(
      initialPage: _currentPage,
    );

    // listen to google sign in state change
    _googleSignIn.onCurrentUserChanged.listen((GoogleSignInAccount account) {
      handleSignIn(account);
    }, onError: (error) {
      print("GoogleLoginError: $error");
    });

    // check for auth session
    _googleSignIn.signInSilently(suppressErrors: false).then((GoogleSignInAccount account) {
      handleSignIn(account);
    }).catchError((error) {
      print("GoogleLoginError: $error");
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void handleSignIn(GoogleSignInAccount account) async {
    if (account != null) {
      await createUserInFirestore();
      setState(() {
        _isAuth = true;
      });
    } else {
      setState(() {
        _isAuth = false;
      });
    }
  }

  void login() {
    _googleSignIn.signIn();
  }

  void logout() {
    _googleSignIn.signOut();
  }

  Future createUserInFirestore() async {
    // check if user exists in users collection
    GoogleSignInAccount user = _googleSignIn.currentUser;
    DocumentSnapshot doc = await usersRef.doc(user.id).get();

    // if user does not exist, redirect to create account page
    if (!doc.exists) {
      dynamic username = await Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => CreateAccount()),
      );

      // create new user with given username
      await usersRef.doc(user.id).set({
        'id': user.id,
        'username': username,
        'photoUrl': user.photoUrl,
        'email': user.email,
        'displayName': user.displayName,
        'bio': '',
        'timestamp': _timestamp,
      });

      doc = await usersRef.doc(user.id).get();
    }

    _currentUser = User.fromDocument(doc);
  }

  void onPageChanged(int page) {
    setState(() {
      _currentPage = page;
    });
  }

  void onTap(int page) {
    _pageController.animateToPage(
      page,
      curve: Curves.easeInOut,
      duration: Duration(milliseconds: 300),
    );
  }

  Widget buildAuthScreen() {
    return Scaffold(
      body: PageView(
        controller: _pageController,
        onPageChanged: onPageChanged,
        physics: NeverScrollableScrollPhysics(),
        children: [
          // Timeline(),
          RaisedButton(
            onPressed: () {
              _googleSignIn.signOut();
            },
            child: Text('Logout'),
          ),
          ActivityFeed(),
          Upload(user: _currentUser),
          Search(),
          Profile(),
        ],
      ),
      bottomNavigationBar: CupertinoTabBar(
        currentIndex: _currentPage,
        onTap: onTap,
        activeColor: Theme.of(context).primaryColor,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.whatshot)),
          BottomNavigationBarItem(icon: Icon(Icons.notifications_active)),
          BottomNavigationBarItem(icon: Icon(Icons.photo_camera, size: 35)),
          BottomNavigationBarItem(icon: Icon(Icons.search)),
          BottomNavigationBarItem(icon: Icon(Icons.account_circle)),
        ],
      ),
    );
  }

  Widget buildUnAuthScreen() {
    return Scaffold(
      body: Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [
              Theme.of(context).accentColor,
              Theme.of(context).primaryColor,
            ],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'FlutterShare',
              style: TextStyle(
                fontFamily: 'Signatra',
                fontSize: 90,
                color: Colors.white,
              ),
            ),
            GestureDetector(
              onTap: login,
              child: Container(
                width: 260,
                height: 60,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/images/google_signin_button.png'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _isAuth ? buildAuthScreen() : buildUnAuthScreen();
  }
}
